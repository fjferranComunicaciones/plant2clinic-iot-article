#!/usr/bin/env python3
"""
Regenera la tabla S1 por consulta del material suplementario DIRECTAMENTE desde
la fuente maestra de resultados, para que el suplemento no pueda divergir del
cuerpo del articulo.

Fuente maestra : ensayos/camino_a/resultados_s1_camino_a.json  (generatedAt 2026-07-23)
Traducciones   : s1_translations.json  (ES->EN, verificadas: invariante de tokens
                 numericos entre original y traduccion)
Salidas        : bloque longtable insertado en evaluations.tex
                 s1_query_level_results.csv
                 s1_summary.json

Cada fila publica los DOS criterios de acierto que usa el articulo:
  Raw        = coincidencia exacta de cadena con la clave esperada
  Normalized = coincidencia numerica tolerante a formato (6.4 == 6.40)
Asi una fila puede leerse como FAIL(raw)/PASS(norm) sin que el lector concluya
que el sistema no recupero el dato.

Uso: python3 regenerar_tabla_s1.py
"""
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BEGIN_MARK = "% >>> TABLA S1 AUTOGENERADA -- no editar a mano, usar regenerar_tabla_s1.py"
END_MARK = "% <<< FIN TABLA S1 AUTOGENERADA"
MASTER = "/Users/javierferrandez/Desktop/TRAZABILIDAD/ensayos/camino_a/resultados_s1_camino_a.json"
TRANSL = os.path.join(HERE, "s1_translations.json")
EVALTEX = os.path.join(HERE, "evaluations.tex")

# Mapa de categorias ES->EN. Cerrado y verificado contra el JSON maestro:
# el script aborta si aparece una categoria no contemplada.
CATMAP = {
    "Genetica THC": "Genetics -- THC",
    "Genetica CBD": "Genetics -- CBD",
    "Genetica terpenos": "Genetics -- terpenes",
    "Documental geneticas": "Genetics -- documentary",
    "SOP clones": "SOP -- clones",
    "SOP secado": "SOP -- drying",
    "SOP humedad": "SOP -- humidity",
    "Bioseguridad": "Biosafety",
    "Cultivo": "Cultivation",
    "IoT pH": "IoT -- pH",
    "IoT EC": "IoT -- EC",
    "RAG": "RAG",
    "Trazabilidad": "Traceability",
    "Auditoria": "Audit",
    "Validaciones": "Validations",
    "IoT": "IoT",
    "Inventario": "Inventory",
    "Blockchain": "Blockchain",
    "Ensayo clinico": "Clinical trial",
    "Extraccion": "Extraction",
    "Almacenamiento": "Storage",
    "Calidad": "Quality",
    "Alertas": "Alerts",
    "Documentos": "Documents",
}


# Simbolos no ASCII que aparecen en los registros del sistema. Se traducen a su
# equivalente LaTeX: el documento se compila con pdflatex/OT1, que los rechaza
# como carácter literal. Preservan el significado, no lo eliminan.
UNICODE_TEX = {
    "\u00b0": r"$^{\circ}$",   # grado
    "\u2264": r"$\leq$",       # menor o igual
    "\u2265": r"$\geq$",       # mayor o igual
    "\u00d7": r"$\times$",     # multiplicacion
    "\u2014": "---",           # raya
    "\u2013": "--",            # semirraya
    "\u2022": r"$\bullet$",    # vineta
    "\u00b5": r"$\mu$",
    "\u2192": r"$\rightarrow$",
    "\u201c": "``", "\u201d": "''", "\u2018": "`", "\u2019": "'",
    "\u00a0": " ",
}


def tex_escape(t):
    """Escapa para LaTeX. El texto viene de registros de sistema, no de LaTeX."""
    t = re.sub(r"\s+", " ", (t or "")).strip()
    for a, b in (("\\", r"\textbackslash{}"), ("&", r"\&"), ("%", r"\%"),
                 ("$", r"\$"), ("#", r"\#"), ("_", r"\_"), ("{", r"\{"),
                 ("}", r"\}"), ("~", r"\textasciitilde{}"),
                 ("^", r"\textasciicircum{}")):
        t = t.replace(a, b)
    for a, b in UNICODE_TEX.items():
        t = t.replace(a, b)
    # Cualquier no-ASCII restante haria fallar la compilacion en silencio si se
    # dejara pasar: mejor abortar y anadirlo al mapa de arriba.
    rest = sorted(set(ch for ch in t if ord(ch) > 127))
    if rest:
        sys.exit("caracter no ASCII sin equivalente LaTeX: %s en %r" % (
            [hex(ord(c)) for c in rest], t[:120]))
    # Las respuestas citan rutas de fichero (validated_info/X_RNCP.md) que TeX
    # trata como una palabra indivisible y desbordan el filete de la columna.
    # \allowbreak es un punto de corte invisible: no anade ningun caracter al
    # texto publicado, solo autoriza a partir ahi si la linea no cabe.
    for sep in ("/", r"\_"):
        t = t.replace(sep, sep + r"\allowbreak{}")
    return t


def num_tokens(t):
    return sorted(re.findall(r"\d+(?:[.,]\d+)?", t or ""))


def load():
    master = json.load(open(MASTER))
    transl = {int(k): v for k, v in json.load(open(TRANSL)).items()}
    rows = master["rows"]
    unknown = set(r["category"] for r in rows) - set(CATMAP)
    if unknown:
        sys.exit("categorias sin traduccion: %s" % sorted(unknown))
    missing = set(r["id"] for r in rows) - set(transl)
    if missing:
        sys.exit("filas sin traduccion: %s" % sorted(missing))
    return master, rows, transl


def build_longtable(rows, transl):
    """Tabla apaisada. El ancho util en apaisado es \\textheight = 550pt = 19.35cm;
    con \\tabcolsep 4pt las 8 columnas consumen 2.25cm en separadores, de modo que
    quedan ~16.9cm para los anchos p{} de abajo (suman 16.8cm). La version anterior
    de esta tabla, en vertical, sumaba 17cm de columnas sobre 12.13cm utiles: la
    ultima columna se cortaba en el margen. \\raggedright evita la justificacion
    forzada, que en columnas estrechas produce huecos entre palabras."""
    head = (r"\textbf{\#} & \textbf{Category} & \textbf{Route} & \textbf{Question} "
            r"& \textbf{Expected Key} & \textbf{Raw} & \textbf{Norm.} "
            r"& \textbf{Response Extract} \\")
    RG = r">{\raggedright\arraybackslash}"
    cols = "|".join(RG + "p{%s}" % w for w in
                    ("0.8cm", "2.0cm", "1.0cm", "4.0cm", "2.0cm", "1.0cm", "1.1cm", "4.9cm"))
    out = [
        r"\begin{landscape}",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{4pt}",
        r"\begin{longtable}{|" + cols + "|}",
        r"\hline", head, r"\hline", r"\endfirsthead",
        r"\multicolumn{8}{c}%",
        r"{{\tablename\ \thetable\ -- continued from previous page}} \\",
        r"\hline", head, r"\hline", r"\endhead",
        r"\hline \multicolumn{8}{r}{{Continued on next page}} \\",
        r"\endfoot", r"\hline", r"\endlastfoot",
    ]
    for r in sorted(rows, key=lambda x: x["id"]):
        eq, ea = transl[r["id"]]
        out.append(" %d & %s & %s & %s & %s & %s & %s & %s \\\\" % (
            r["id"],
            tex_escape(CATMAP[r["category"]]),
            r["route"],
            tex_escape(eq),
            tex_escape(", ".join(r["expected"])),
            "PASS" if r["rawSuccess"] else r"\textbf{FAIL}",
            "PASS" if r["normSuccess"] else r"\textbf{FAIL}",
            tex_escape(ea),
        ))
    out.append(r"\end{longtable}")
    out.append(r"\end{landscape}")
    return "\n".join(out)


def write_csv(rows, transl, path):
    import csv
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["id", "category_es", "category_en", "route", "question_es",
                    "question_en", "expected_key", "numeric_key", "raw_success",
                    "norm_success", "latency_ms", "timed_out", "answer_extract_en"])
        for r in sorted(rows, key=lambda x: x["id"]):
            eq, ea = transl[r["id"]]
            w.writerow([r["id"], r["category"], CATMAP[r["category"]], r["route"],
                        r["question"], eq, "|".join(r["expected"]),
                        int(bool(r.get("numeric"))), int(r["rawSuccess"]),
                        int(r["normSuccess"]), r["elapsedMs"],
                        int(bool(r.get("timedOut"))), ea])


def main():
    master, rows, transl = load()

    # --- invariantes contra la fuente maestra -------------------------------
    assert len(rows) == 100, len(rows)
    raw_fail = sorted(r["id"] for r in rows if not r["rawSuccess"])
    norm_fail = sorted(r["id"] for r in rows if not r["normSuccess"])
    assert raw_fail == [22, 23], raw_fail
    assert norm_fail == [], norm_fail
    r24 = next(r for r in rows if r["id"] == 24)
    assert r24["category"] == "Genetica CBD" and r24["rawSuccess"], r24
    s = master["summary"]
    assert (s["S1_1_deterministic"]["n"], s["S1_1_deterministic"]["rawCorrect"]) == (36, 34)
    assert (s["S1_2_generative"]["n"], s["S1_2_generative"]["rawCorrect"]) == (64, 64)
    assert (s["overall"]["rawCorrect"], s["overall"]["normCorrect"]) == (98, 100)
    for r in rows:
        eq, _ = transl[r["id"]]
        assert num_tokens(r["question"]) == num_tokens(eq), r["id"]

    # --- tabla ---------------------------------------------------------------
    block = build_longtable(rows, transl)
    ev = open(EVALTEX).read()
    tables = re.findall(r"\\begin\{longtable\}.*?\\end\{longtable\}", ev, re.S)
    if len(tables) != 2:
        sys.exit("evaluations.tex: se esperaban 2 longtable, hay %d" % len(tables))
    # Reemplazo idempotente mediante marcadores. En la primera ejecucion no
    # existen todavia y se sustituye la primera longtable; a partir de ahi se
    # sustituye siempre el bloque delimitado, envoltura landscape incluida.
    if BEGIN_MARK in ev and END_MARK in ev:
        i0 = ev.find(BEGIN_MARK)
        i1 = ev.find(END_MARK) + len(END_MARK)
        ev_new = ev[:i0] + BEGIN_MARK + "\n" + block + "\n" + END_MARK + ev[i1:]
    else:
        ev_new = ev.replace(tables[0], BEGIN_MARK + "\n" + block + "\n" + END_MARK, 1)
    open(EVALTEX, "w").write(ev_new)

    # --- exportables ---------------------------------------------------------
    write_csv(rows, transl, os.path.join(HERE, "s1_query_level_results.csv"))
    json.dump({"source": os.path.basename(MASTER),
               "generatedAt": master["generatedAt"],
               "summary": master["summary"],
               "raw_failures": raw_fail,
               "normalized_failures": norm_fail},
              open(os.path.join(HERE, "s1_summary.json"), "w"), indent=1)

    print("filas publicadas      : %d" % len(rows))
    print("fallos raw            : %s" % raw_fail)
    print("fallos normalizados   : %s" % norm_fail)
    print("S1-1 raw / norm       : %d/36 -> %d/36" % (
        s["S1_1_deterministic"]["rawCorrect"], s["S1_1_deterministic"]["normCorrect"]))
    print("S1-2 raw / norm       : %d/64 -> %d/64" % (
        s["S1_2_generative"]["rawCorrect"], s["S1_2_generative"]["normCorrect"]))
    print("global raw / norm     : %d/100 -> %d/100" % (
        s["overall"]["rawCorrect"], s["overall"]["normCorrect"]))


if __name__ == "__main__":
    main()
