PLANT2CLINIC supplementary evaluation records

The CSV contains the 100-query S1 evaluation. JSON files provide summaries, translations and recorded abstention/gate-fix benchmark results. Scripts are retained from the original submission and require their original project environment, source logs and/or local model services; this archive is not a standalone software distribution. No new experiments were run for the Array submission.
