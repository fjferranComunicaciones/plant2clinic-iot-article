# Evidencia S2

`interno/iot_evidencia_snapshot.db` es una copia consistente SQLite para trabajo interno; no va en los paquetes editoriales. Los datos de campo no se han publicado.

`resultados_s2_real.json` y `informe_s2_real.md` son salidas históricas conservadas sin modificar. Su campo span corresponde a iot_readings (tres semanas), no al histórico de agent_runs (once semanas). El script original `validate_s2_real.py` referencia la estructura original del proyecto; se conserva como procedencia, no como un comando listo para ejecutar desde esta carpeta.

El manuscrito precisa que se revisan anomalías ya registradas: 136.005 comprobaciones de banda y 54.982 estados agregados, con 284 estados OFFLINE excluidos. El código reutiliza los niveles de condiciones combinadas. Los resultados no prueban la detección exhaustiva de anomalías.

`resultados_s2_determinista.json` conserva la prueba separada de 100 interacciones de la que procede la temporización; no se presenta esa latencia como medida de extremo a extremo de las lecturas de campo.
