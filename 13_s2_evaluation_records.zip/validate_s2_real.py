#!/usr/bin/env python3
"""
Validación S2 con telemetría REAL de campo (Camino A).

Contrasta la clasificación determinista que el agente S2 almacenó en
agent_runs (sobre lecturas reales del gemelo digital, local_iot/iot.db)
contra una RE-DERIVACIÓN INDEPENDIENTE del estado, reimplementando en
Python el algoritmo de bandas documentado en server/iot.js
(metricState + evaluateReading).

QUÉ VALIDA: la fidelidad determinista del motor S2 — que clasifica cada
lectura exactamente según su política publicada (target/alarm) — y su
reproducibilidad, sobre N reales de campo (3 semanas, 3 salas activas).

QUÉ NO VALIDA: la corrección agronómica de los propios umbrales (si las
bandas son clínicamente/agronómicamente correctas). Eso requiere ground
truth experto y queda fuera de alcance.

Uso: python3 validate_s2_real.py  (lee ../../local_iot/iot.db)
Salidas: resultados_s2_real.json, informe_s2_real.md
"""
import sqlite3, json, statistics, os
from collections import Counter, defaultdict

HERE=os.path.dirname(os.path.abspath(__file__))
DB=os.path.join(HERE,"..","..","local_iot","iot.db")
DET=os.path.join(HERE,"..","rag_ollama_gemelo_2026-06-22","resultados_s2_determinista.json")

def metric_state(bands, v):
    if v is None: return None
    al=bands.get('alarm') or {}; tg=bands.get('target') or {}
    if al.get('min') is not None and v<al['min']: return ('alarm','low')
    if al.get('max') is not None and v>al['max']: return ('alarm','high')
    if tg.get('min') is not None and v<tg['min']: return ('warning','low')
    if tg.get('max') is not None and v>tg['max']: return ('warning','high')
    return ('ok',None)

c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
rows=c.execute("SELECT id, room_id, output_json, status FROM agent_runs WHERE agent='S2_IOT'").fetchall()
span=c.execute("SELECT MIN(observed_at) a, MAX(observed_at) b FROM iot_readings").fetchone()

stored=Counter(); rederived=Counter()
anom_total=0; anom_mm=0
ov_total=0; ov_mm=0; mismatches=[]
fresh=Counter()
per_room=defaultdict(lambda:{'n':0,'anom':0,'anom_mm':0,'ov_n':0,'ov_mm':0})
for r in rows:
    ev=json.loads(r['output_json']).get('evaluation') or {}
    st=ev.get('status'); anoms=ev.get('anomalies') or []
    stored[st]+=1; pr=per_room[r['room_id']]; pr['n']+=1
    lv=[]
    for a in anoms:
        if a.get('metric')=='combination': lv.append(a.get('level')); continue
        ms=metric_state({'alarm':a.get('alarm'),'target':a.get('target')}, a.get('current'))
        anom_total+=1; pr['anom']+=1
        if ms is None or ms[0]=='ok' or ms[0]!=a.get('level') or ms[1]!=a.get('direction'):
            anom_mm+=1; pr['anom_mm']+=1
        lv.append(a.get('level'))
    if st in ('OFFLINE','STALE'): fresh[st]+=1; continue
    rd='ALARM' if any(l=='alarm' for l in lv) else ('WARNING' if anoms else 'OK')
    rederived[rd]+=1; ov_total+=1; pr['ov_n']+=1
    if rd!=st:
        ov_mm+=1; pr['ov_mm']+=1
        if len(mismatches)<20: mismatches.append({'id':r['id'],'stored':st,'rederived':rd,'n_anom':len(anoms)})

# latencia real por evaluación
evms=[]
try:
    d=json.load(open(DET)); evms=[float(x['evalMs']) for x in d['results'] if x.get('evalMs')]
except Exception: pass
lat=None
if evms:
    s=sorted(evms)
    lat={'n':len(s),'median_ms':round(statistics.median(s),3),
         'p90_ms':round(s[int(0.9*len(s))],3),'p95_ms':round(s[min(int(0.95*len(s)),len(s)-1)],3),
         'min_ms':round(min(s),3),'max_ms':round(max(s),3)}

out={
 'dataset':{'db':'local_iot/iot.db','span':{'from':span['a'],'to':span['b']},
            'n_s2_runs':len(rows),'active_rooms':len([k for k,v in per_room.items() if v['n']>10])},
 'stored_status_distribution':dict(stored),
 'freshness_excluded':dict(fresh),
 'per_anomaly_banding':{'checked':anom_total,'mismatches':anom_mm,
                        'agreement_pct':round(100*(anom_total-anom_mm)/anom_total,4) if anom_total else None},
 'overall_status':{'checked':ov_total,'mismatches':ov_mm,
                   'agreement_pct':round(100*(ov_total-ov_mm)/ov_total,4) if ov_total else None,
                   'rederived_distribution':dict(rederived)},
 'per_room':{k:dict(v) for k,v in per_room.items()},
 'latency_per_eval_ms':lat,
 'mismatch_examples':mismatches,
 'scope_note':'Valida fidelidad determinista y reproducibilidad frente a la politica publicada; NO valida la correccion agronomica de los umbrales.'
}
json.dump(out, open(os.path.join(HERE,"resultados_s2_real.json"),"w"), indent=2, ensure_ascii=False)

with open(os.path.join(HERE,"informe_s2_real.md"),"w") as f:
    f.write("# Validación S2 con telemetría real de campo (Camino A)\n\n")
    f.write(f"Fuente: `local_iot/iot.db` · Periodo: {span['a']} → {span['b']}\n\n")
    f.write(f"- Ejecuciones S2 reales evaluadas: **{len(rows):,}**\n")
    f.write(f"- Concordancia por-anomalía (bandas): **{out['per_anomaly_banding']['agreement_pct']}%** ({anom_total:,} decisiones, {anom_mm} discrepancias)\n")
    f.write(f"- Concordancia de estado global OK/WARNING/ALARM: **{out['overall_status']['agreement_pct']}%** ({ov_total:,} evaluadas, {ov_mm} discrepancias)\n")
    f.write(f"- Estados excluidos por frescura (OFFLINE/STALE): {dict(fresh)}\n")
    if lat: f.write(f"- Latencia real por evaluación: mediana **{lat['median_ms']} ms**, p90 {lat['p90_ms']} ms, máx {lat['max_ms']} ms (n={lat['n']})\n")
    f.write(f"\n**Alcance:** {out['scope_note']}\n\n## Distribución de estados (almacenados)\n")
    for k,v in stored.items(): f.write(f"- {k}: {v:,}\n")
    f.write("\n## Por sala\n| Sala | n | anomalías (mm) | estado global n (mm) |\n|---|--:|--:|--:|\n")
    for rm,d in per_room.items(): f.write(f"| {rm} | {d['n']:,} | {d['anom']:,} ({d['anom_mm']}) | {d['ov_n']:,} ({d['ov_mm']}) |\n")

print("OK")
print(json.dumps({k:out[k] for k in ['dataset','per_anomaly_banding','overall_status','latency_per_eval_ms']}, indent=2, ensure_ascii=False))
