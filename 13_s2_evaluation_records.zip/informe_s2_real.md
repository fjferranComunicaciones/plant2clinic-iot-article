# Validación S2 con telemetría real de campo (Camino A)

Fuente: `local_iot/iot.db` · Periodo: 2026-05-26T07:30:00.141Z → 2026-06-16T11:20:00.276Z

- Ejecuciones S2 reales evaluadas: **55,266**
- Concordancia por-anomalía (bandas): **100.0%** (136,005 decisiones, 0 discrepancias)
- Concordancia de estado global OK/WARNING/ALARM: **100.0%** (54,982 evaluadas, 0 discrepancias)
- Estados excluidos por frescura (OFFLINE/STALE): {'OFFLINE': 284}
- Latencia real por evaluación: mediana **0.24 ms**, p90 0.4 ms, máx 2.07 ms (n=100)

**Alcance:** Valida fidelidad determinista y reproducibilidad frente a la politica publicada; NO valida la correccion agronomica de los umbrales.

## Distribución de estados (almacenados)
- ALARM: 36,556
- WARNING: 17,753
- OK: 673
- OFFLINE: 284

## Por sala
| Sala | n | anomalías (mm) | estado global n (mm) |
|---|--:|--:|--:|
| room_clones | 13,529 | 33,303 (0) | 13,388 (0) |
| room_madres | 13,748 | 34,434 (0) | 13,605 (0) |
| room_vegetativo | 27,988 | 68,268 (0) | 27,988 (0) |
| room_floracion | 1 | 0 (0) | 1 (0) |
